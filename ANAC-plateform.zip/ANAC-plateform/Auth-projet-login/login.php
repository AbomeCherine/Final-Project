<?php

session_start();
require_once 'config.php';

$host = "localhost\\SQLEXPRESS";
$db = "projet_login";
$user = "";
$pass = "";
$dsn = "sqlsrv:Server=$host;Database=$db";
try {
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['role']) && ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'super_admin')) {
        header('Location: admin/dashboard.php');
    } elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'manager') {
        header('Location: manager/dashboard.php');
    } else {
        header('Location: dashboard.php');
    }
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($login) || empty($password)) {
        $error = "Please fill up all fields.";
    } else {
        $sql = "SELECT id, username, email, password, role FROM users WHERE username = ? OR email = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$login, $login]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            
            if ($user['role'] === 'admin' || $user['role'] === 'super_admin') {
                header('Location: admin/dashboard.php');
            } elseif ($user['role'] === 'manager') {
                header('Location: manager/dashboard.php');
            } else {
                header('Location: dashboard.php');
            }
            exit();
        } else {
            $error = "Invalid username, email or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0a1928 0%, #1d4a6e 50%, #2c6e9e 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .container {
            background: rgba(255, 255, 255, 0.98);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 450px;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(44, 110, 158, 0.3);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #1a4d6b;
            font-size: 2em;
            font-weight: 600;
            letter-spacing: -0.5px;
        }

        input, select {
            width: 100%;
            padding: 14px;
            margin: 10px 0;
            border: 1px solid #c0d4e8;
            border-radius: 10px;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            transition: all 0.3s ease;
            background: #ffffff;
            color: #1a3a5c;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #2c6e9e;
            box-shadow: 0 0 8px rgba(44, 110, 158, 0.3);
        }

        button {
            width: 100%;
            padding: 14px;
            background: #1a4d6b;
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            font-weight: 500;
            margin-top: 10px;
            transition: all 0.3s ease;
        }

        button:hover {
            background: #2c6e9e;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }

        .error {
            color: #c0392b;
            margin: 10px 0;
            text-align: center;
            font-size: 14px;
            font-weight: 400;
        }

        .link {
            text-align: center;
            margin-top: 25px;
            font-size: 14px;
            font-weight: 400;
            color: #5a7a9a;
        }

        a {
            color: #1a4d6b;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        a:hover {
            color: #2c6e9e;
            text-decoration: underline;
        }

        .login-as {
            margin: 20px 0;
            padding: 15px;
            background: #f0f5f8;
            border-radius: 10px;
            border: 1px solid #d0e0e8;
        }

        .login-as label {
            display: block;
            font-size: 13px;
            color: #5a7a9a;
            margin-bottom: 8px;
        }

        hr {
            margin: 20px 0;
            border: none;
            border-top: 1px solid #e0e8f0;
        }

        @media (max-width: 600px) {
            .container {
                padding: 30px 25px;
            }
            h2 {
                font-size: 1.6em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>You can login here</h2>
        
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="" id="loginForm">
            <input type="text" name="login" id="loginInput" placeholder="Username or email" required>
            <input type="password" name="password" id="passwordInput" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>

        <hr>

        
        <div class="login-as">
            <label>Login as:</label>
            <select id="quickLogin">
                <option value="">-- Choisir un rôle --</option>
                <option value="super_admin">Super Admin (Miroir)</option>
                <option value="admin">Admin (Manon)</option>
                <option value="manager">Manager (Mine)</option>
                <option value="staff">Staff (Mignon)</option>
            </select>
        </div>
        
        <div class="link">
            No account yet ? <a href="register.php">Register here</a> 
        </div>
    </div>

    <script>
       
        const testAccounts = {
            super_admin: { login: 'Miroir', password: 'password123' },
            admin: { login: 'Manon', password: 'password123' },
            manager: { login: 'Mine', password: 'password123' },
            staff: { login: 'Mignon', password: 'password123' }
        };

       
        document.getElementById('quickLogin').addEventListener('change', function() {
            const role = this.value;
            if (role && testAccounts[role]) {
                const account = testAccounts[role];
                document.getElementById('loginInput').value = account.login;
                document.getElementById('passwordInput').value = account.password;
               
                document.getElementById('loginForm').submit();
            }
        });
    </script>
</body>
</html>