<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require_once 'config.php';


$canCreate = false;

if ($_SESSION['role'] === 'super_admin') {
    $canCreate = true;
} elseif ($_SESSION['role'] === 'admin') {
    $stmt = $pdo->prepare("SELECT can_create_forms FROM organizations WHERE id = ?");
    $stmt->execute([$_SESSION['org_id']]);
    $org = $stmt->fetch();
    $canCreate = ($org && $org['can_create_forms'] == 1);
}

if (!$canCreate) {
    die("Vous n'avez pas l'autorisation de créer des formulaires. Contactez votre Super Admin.");
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $fields = [];
    
    if (isset($_POST['field_label'])) {
        for ($i = 0; $i < count($_POST['field_label']); $i++) {
            if (!empty($_POST['field_label'][$i])) {
                $fields[] = [
                    'label' => $_POST['field_label'][$i],
                    'type' => $_POST['field_type'][$i],
                    'options' => $_POST['field_options'][$i] ?? ''
                ];
            }
        }
    }
    
    $form_schema = json_encode($fields);
    
    $sql = "INSERT INTO forms (organization_id, title, description, form_schema) VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    
    if ($stmt->execute([$_SESSION['org_id'], $title, $description, $form_schema])) {
        $success = "Formulaire créé avec succès !";
        auditLog($pdo, 'create_form', 'form', $pdo->lastInsertId(), null, ['title' => $title]);
    } else {
        $error = "Erreur lors de la création.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Créer un formulaire - Aviation Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0a1928 0%, #1d4a6e 100%);
            padding: 40px;
            min-height: 100vh;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 35px;
            border-radius: 20px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.2);
        }
        h1 { color: #1a4d6b; margin-bottom: 10px; }
        .subtitle { color: #5a7a9a; margin-bottom: 30px; }
        input, textarea, select {
            width: 100%;
            padding: 12px;
            margin: 8px 0 15px 0;
            border: 1px solid #c0d4e8;
            border-radius: 10px;
            font-family: 'Poppins', sans-serif;
        }
        button {
            background: #1a4d6b;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            margin-right: 10px;
        }
        button:hover { background: #2c6e9e; }
        .field-item {
            background: #f0f5f8;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 15px;
        }
        .btn-add { background: #27ae60; margin: 10px 0 20px 0; }
        .btn-add:hover { background: #219a54; }
        .btn-remove { background: #e74c3c; padding: 8px 15px; font-size: 12px; }
        .success { background: #d4edda; color: #155724; padding: 12px; border-radius: 10px; margin-bottom: 20px; }
        .error { background: #f8d7da; color: #721c24; padding: 12px; border-radius: 10px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Créer un formulaire</h1>
        <p class="subtitle">Créez un formulaire pour collecter des données</p>
        
        <?php if ($success): ?>
            <div class="success">Success: <?= $success ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error">Error: <?= $error ?></div>
        <?php endif; ?>
        
        <form method="POST" id="formBuilder">
            <input type="text" name="title" placeholder="Titre du formulaire" required>
            <textarea name="description" placeholder="Description" rows="3"></textarea>
            
            <h3>Champs du formulaire</h3>
            <div id="fieldsContainer"></div>
            <button type="button" class="btn-add" onclick="addField()">+ Ajouter un champ</button>
            
            <button type="submit">Créer le formulaire</button>
        </form>
    </div>
    
    <script>
        let fieldCount = 0;
        
        function addField() {
            const container = document.getElementById('fieldsContainer');
            const div = document.createElement('div');
            div.className = 'field-item';
            div.innerHTML = `
                <input type="text" name="field_label[${fieldCount}]" placeholder="Label du champ" required>
                <select name="field_type[${fieldCount}]" onchange="toggleOptions(this, ${fieldCount})">
                    <option value="text">Texte court</option>
                    <option value="textarea">Texte long</option>
                    <option value="email">Email</option>
                    <option value="number">Nombre</option>
                    <option value="select">Liste déroulante</option>
                    <option value="radio">Bouton radio</option>
                    <option value="checkbox">Case à cocher</option>
                </select>
                <input type="text" name="field_options[${fieldCount}]" placeholder="Options (séparées par |) pour select/radio" style="display:none;">
                <button type="button" class="btn-remove" onclick="this.parentElement.remove()">Supprimer</button>
            `;
            container.appendChild(div);
            fieldCount++;
        }
        
        function toggleOptions(select, index) {
            const optionsInput = document.querySelector(`input[name="field_options[${index}]"]`);
            if (select.value === 'select' || select.value === 'radio' || select.value === 'checkbox') {
                optionsInput.style.display = 'block';
            } else {
                optionsInput.style.display = 'none';
            }
        }
    </script>
</body>
</html>