<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];
    
    // Validation
    if (empty($username) || empty($email) || empty($password)) {
        $error = "Tous les champs sont obligatoires.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Email invalide.";
    } elseif (strlen($password) < 6) {
        $error = "Mot de passe (min 6 caractères).";
    } elseif ($password !== $confirm_password) {
        $error = "Les mots de passe ne correspondent pas.";
    } else {
        // Vérifier si l'utilisateur existe déjà
        $check = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->execute([$username, $email]);
        
        if ($check->rowCount() > 0) {
            $error = "Nom d'utilisateur ou email déjà utilisé.";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            
            // Insertion SANS le champ 'code' (car il n'existe pas dans ta table)
            $sql = "INSERT INTO users (username, email, password, role, organization_id) VALUES (?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            
            $org_id = 1; // Organisation par défaut (ANAC Gabon)
            
            if ($stmt->execute([$username, $email, $hashed, $role, $org_id])) {
                $success = "Inscription réussie ! Vous pouvez vous connecter.";
            } else {
                $error = "Erreur lors de l'inscription.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription - Aviation Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0a1928 0%, #1d4a6e 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 20px;
            max-width: 500px;
            width: 100%;
        }
        h2 {
            color: #1a4d6b;
            text-align: center;
            margin-bottom: 10px;
        }
        .subtitle {
            text-align: center;
            color: #5a7a9a;
            margin-bottom: 30px;
            font-size: 14px;
        }
        input, select {
            width: 100%;
            padding: 14px;
            margin: 8px 0;
            border: 1px solid #c0d4e8;
            border-radius: 10px;
            font-family: 'Poppins', sans-serif;
        }
        button {
            width: 100%;
            padding: 14px;
            background: #1a4d6b;
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            margin-top: 15px;
            font-weight: 600;
        }
        .error { color: #c0392b; margin: 10px 0; }
        .success { color: #27ae60; margin: 10px 0; }
        .link { text-align: center; margin-top: 20px; }
        a { color: #1a4d6b; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Inscription</h2>
        <div class="subtitle">Créez votre compte</div>
        
        <?php if ($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="text" name="username" placeholder="Nom d'utilisateur" value="Manon" required>
            <input type="email" name="email" placeholder="Email" value="manon@gmail.com" required>
            <select name="role" required>
                <option value="staff">Staff (membre)</option>
                <option value="manager">Manager</option>
                <option value="admin">Admin</option>
                <option value="super_admin">Super Admin</option>
            </select>
            <input type="password" name="password" placeholder="Mot de passe (min 6 caractères)" required>
            <input type="password" name="confirm_password" placeholder="Confirmer le mot de passe" required>
            <button type="submit">S'inscrire</button>
        </form>
        
        <div class="link">
            Déjà un compte ? <a href="login.php">Se connecter</a>
        </div>
    </div>
</body>
</html>