<?php
session_start();
require_once 'config.php';


if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'super_admin') {
        header('Location: admin/dashboard.php');
        exit();
    } elseif ($_SESSION['role'] === 'manager') {
        header('Location: manager/dashboard.php');
        exit();
    }
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


$stmt = $pdo->prepare("SELECT id, title, description, created_at FROM forms WHERE organization_id = ? AND is_published = 1 ORDER BY created_at DESC");
$stmt->execute([$_SESSION['org_id']]);
$forms = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT s.id, s.submitted_at, f.title as form_title, CASE WHEN s.status IS NULL OR s.status = '' THEN 'En attente' ELSE s.status END as status FROM submissions s JOIN forms f ON s.form_id = f.id WHERE s.submitted_by = ? ORDER BY s.submitted_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$mySubmissions = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM tasks WHERE assigned_to = ? ORDER BY CASE status WHEN 'pending' THEN 1 WHEN 'in_progress' THEN 2 ELSE 3 END, due_date ASC");
$stmt->execute([$_SESSION['user_id']]);
$myTasks = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon espace - Aviation Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: #f0f2f5;
            min-height: 100vh;
        }
       
        .sidebar {
            width: 280px;
            background: #0a1928;
            position: fixed;
            height: 100vh;
            padding: 25px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        .sidebar h2 {
            color: white;
            font-size: 1.3em;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #1d4a6e;
        }
        .sidebar a {
            display: block;
            color: #a0c0d8;
            padding: 12px 15px;
            text-decoration: none;
            margin: 5px 0;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .sidebar a:hover, .sidebar a.active {
            background: #1a4d6b;
            color: white;
        }
        .content {
            margin-left: 280px;
            padding: 30px;
        }
        .header {
            background: white;
            padding: 20px 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { color: #1a4d6b; font-size: 1.5em; }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            text-align: center;
        }
        .stat-number { font-size: 2.5em; font-weight: 700; color: #1a4d6b; }
        .stat-label { color: #5a7a9a; margin-top: 10px; }
        .section-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 30px;
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e0e8f0;
        }
        .btn {
            display: inline-block;
            padding: 8px 20px;
            background: #1a4d6b;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
        }
        .btn:hover { background: #2c6e9e; }
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }
        .form-card {
            background: #f0f5f8;
            padding: 20px;
            border-radius: 12px;
            border: 1px solid #d0e0e8;
        }
        .form-card h3 { color: #1a4d6b; margin-bottom: 10px; }
        .form-card p { color: #5a7a9a; font-size: 14px; margin-bottom: 15px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e0e8f0; }
        th { background: #f0f5f8; color: #1a4d6b; }
        .task-pending, .task-in_progress, .task-completed { padding: 4px 12px; border-radius: 20px; font-size: 12px; display: inline-block; }
        .task-pending { background: #fff3cd; color: #856404; }
        .task-in_progress { background: #cce5ff; color: #004085; }
        .task-completed { background: #d4edda; color: #155724; }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Mon espace</h2>
        <a href="dashboard.php" class="active">Tableau de bord</a>
        <a href="../logout.php">Déconnexion</a>
    </div>
    <div class="content">
        <div class="header">
            <h1>Tableau de bord</h1>
            <div>Bienvenue, <?php echo htmlspecialchars($_SESSION['username']); ?> (<?php echo $_SESSION['role']; ?>)</div>
        </div>
        <div class="stats-grid">
            <div class="stat-card"><div class="stat-number"><?php echo count($forms); ?></div><div class="stat-label">Formulaires dispo</div></div>
            <div class="stat-card"><div class="stat-number"><?php echo count($mySubmissions); ?></div><div class="stat-label">Mes soumissions</div></div>
            <div class="stat-card"><div class="stat-number"><?php echo count($myTasks); ?></div><div class="stat-label">Mes tâches</div></div>
        </div>
        <div class="section-card">
            <div class="section-header"><h3>Formulaires disponibles</h3></div>
            <?php if (count($forms) > 0): ?>
            <div class="cards-grid">
                <?php foreach ($forms as $form): ?>
                <div class="form-card"><h3><?php echo htmlspecialchars($form['title']); ?></h3><p><?php echo htmlspecialchars($form['description']); ?></p><a href="submit_form.php?id=<?php echo $form['id']; ?>" class="btn">Remplir</a></div>
                <?php endforeach; ?>
            </div>
            <?php else: ?><p>Aucun formulaire</p><?php endif; ?>
        </div>
    </div>
</body>
</html>