<?php
session_start();
require_once 'config.php';

$form_id = $_GET['id'] ?? 0;


$stmt = $pdo->prepare("SELECT * FROM forms WHERE id = ?");
$stmt->execute([$form_id]);
$form = $stmt->fetch();

if (!$form) {
    die("Form not found.");
}

$fields = json_decode($form['form_schema'], true);
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $responses = [];
    foreach ($fields as $field) {
        $responses[$field['label']] = $_POST[$field['label']] ?? '';
    }
    
    $sql = "INSERT INTO submissions (form_id, response_data) VALUES (?, ?)";
    $stmt = $pdo->prepare($sql);
    
    if ($stmt->execute([$form_id, json_encode($responses)])) {
        $success = "Thank you! Your response has been recorded.";
        auditLog($pdo, 'submit_form', 'submission', $pdo->lastInsertId());
    } else {
        $error = "Error while sending.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($form['title']) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background: linear-gradient(135deg, #0a1928 0%, #1d4a6e 100%); padding: 40px; }
        .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 15px; }
        input, textarea, select { width: 100%; padding: 10px; margin: 10px 0; border-radius: 8px; border: 1px solid #ddd; }
        button { background: #1a4d6b; color: white; padding: 12px 25px; border: none; border-radius: 8px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Fly over the world<?= htmlspecialchars($form['title']) ?></h1>
        <p><?= htmlspecialchars($form['description']) ?></p>
        
        <?php if ($success): ?>
            <div style="color: green; background: #e8f5e9; padding: 15px; border-radius: 8px;">Great <?= $success ?></div>
        <?php else: ?>
            <form method="POST">
                <?php foreach ($fields as $field): ?>
                    <label><?= htmlspecialchars($field['label']) ?></label>
                    
                    <?php if ($field['type'] == 'textarea'): ?>
                        <textarea name="<?= htmlspecialchars($field['label']) ?>" rows="4"></textarea>
                    
                    <?php elseif ($field['type'] == 'select'): ?>
                        <select name="<?= htmlspecialchars($field['label']) ?>">
                            <option value="">-- Choose --</option>
                            <?php 
                            $options = explode('|', $field['options'] ?? '');
                            foreach ($options as $opt): 
                            ?>
                                <option value="<?= trim($opt) ?>"><?= trim($opt) ?></option>
                            <?php endforeach; ?>
                        </select>
                    
                    <?php elseif ($field['type'] == 'radio'): ?>
                        <?php 
                        $options = explode('|', $field['options'] ?? '');
                        foreach ($options as $opt): 
                        ?>
                            <label style="display: inline-block; margin-right: 15px;">
                                <input type="radio" name="<?= htmlspecialchars($field['label']) ?>" value="<?= trim($opt) ?>">
                                <?= trim($opt) ?>
                            </label>
                        <?php endforeach; ?>
                    
                    <?php else: ?>
                        <input type="<?= $field['type'] ?>" name="<?= htmlspecialchars($field['label']) ?>">
                    <?php endif; ?>
                <?php endforeach; ?>
                
                <button type="submit">Send</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>