<?php


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = "localhost\\SQLEXPRESS";  
$dbname = "projet_login";          
$username = "";                    
$password = "";                    

try {
    
    $pdo = new PDO("sqlsrv:Server=$host;Database=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}


if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("
        SELECT u.*, o.id as org_id FROM users u
        LEFT JOIN organizations o ON u.organization_id = o.id
        WHERE u.id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $userData = $stmt->fetch();
    
   if ($userData) {
    $_SESSION['org_id'] = $userData['org_id'] ?? 1;
    $_SESSION['org_name'] = $userData['org_name'] ?? 'ANAC Gabon';
    $_SESSION['org_slug'] = $userData['org_slug'] ?? 'anac-gabon';
    $_SESSION['role'] = $userData['role'] ?? 'staff';
    $_SESSION['username'] = $userData['username'];
    $_SESSION['email'] = $userData['email'];
}
}


/**
 * @param string|string[] $roles
 * @return bool
 */
function hasRole($roles): bool {
    if (!isset($_SESSION['role'])) return false;
    if (is_array($roles)) {
        return in_array($_SESSION['role'], $roles);
    }
    return $_SESSION['role'] === $roles;
}


function auditLog(PDO $pdo, string $action, ?string $entityType = null, ?int $entityId = null, mixed $oldValues = null, mixed $newValues = null): void {
    if (!isset($_SESSION['user_id'])) return;
    
    $stmt = $pdo->prepare("
        INSERT INTO audit_logs (user_id, organization_id, action, entity_type, entity_id, old_values, new_values, ip_address)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $_SESSION['user_id'],
        $_SESSION['org_id'] ?? null,
        $action,
        $entityType,
        $entityId,
        $oldValues ? json_encode($oldValues) : null,
        $newValues ? json_encode($newValues) : null,
        $_SERVER['REMOTE_ADDR'] ?? null
    ]);
}
?>