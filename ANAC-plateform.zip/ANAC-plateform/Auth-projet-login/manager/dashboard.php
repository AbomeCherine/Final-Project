<?php
session_start();
require_once '../config.php';

// Vérifier que l'utilisateur est manager
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'manager') {
    header('Location: ../login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Manager Dashboard - Aviation Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: #f0f2f5;
            min-height: 100vh;
        }
        .header {
            background: #1a4d6b;
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { font-size: 1.5em; }
        .header a { color: white; text-decoration: none; background: #c0392b; padding: 8px 20px; border-radius: 8px; }
        .container { max-width: 1200px; margin: 0 auto; padding: 30px; }
        .card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        h2 { color: #1a4d6b; margin-bottom: 20px; }
        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 25px;
            background: #1a4d6b;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Tableau de bord Manager</h1>
        <div>
            <span><?php echo htmlspecialchars($_SESSION['username']); ?> (Manager)</span>
            <a href="../logout.php">Déconnexion</a>
        </div>
    </div>

    <div class="container">
        <div class="card">
            <h2>Bienvenue sur votre espace Manager</h2>
            <p>Email: <?php echo htmlspecialchars($_SESSION['email']); ?></p>
            <p>Rôle: <?php echo htmlspecialchars($_SESSION['role']); ?></p>
            <a href="../dashboard.php" class="btn">Voir les formulaires</a>
        </div>
    </div>
</body>
</html>