<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || !hasRole(['admin', 'super_admin'])) {
    header('Location: ../login.php');
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM forms WHERE organization_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['org_id']]);
$forms = $stmt->fetchAll();

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM forms WHERE id = ? AND organization_id = ?");
    $stmt->execute([$_GET['delete'], $_SESSION['org_id']]);
    header('Location: forms.php');
    exit();
}

if (isset($_GET['toggle'])) {
    $stmt = $pdo->prepare("UPDATE forms SET is_published = ~is_published WHERE id = ? AND organization_id = ?");
    $stmt->execute([$_GET['toggle'], $_SESSION['org_id']]);
    header('Location: forms.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des formulaires</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: #f0f2f5;
            min-height: 100vh;
        }
        .sidebar {
            width: 280px;
            background: #0a1928;
            position: fixed;
            height: 100vh;
            padding: 25px;
        }
        .sidebar h2 {
            color: white;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #1d4a6e;
        }
        .sidebar a {
            display: block;
            color: #a0c0d8;
            padding: 12px 15px;
            text-decoration: none;
            margin: 5px 0;
            border-radius: 10px;
        }
        .sidebar a:hover, .sidebar a.active {
            background: #1a4d6b;
            color: white;
        }
        .content {
            margin-left: 280px;
            padding: 30px;
        }
        .header {
            background: white;
            padding: 20px 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { color: #1a4d6b; font-size: 1.5em; }
        .card {
            background: white;
            padding: 25px;
            border-radius: 15px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #1a4d6b;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .btn-small {
            padding: 5px 12px;
            font-size: 12px;
            margin: 2px;
        }
        .btn-danger { background: #c0392b; }
        .btn-warning { background: #e67e22; }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e8f0;
        }
        th {
            background: #f0f5f8;
            color: #1a4d6b;
        }
        .badge-published {
            background: #27ae60;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
        }
        .badge-draft {
            background: #e67e22;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>ANAC Aviation</h2>
        <a href="dashboard.php">Tableau de bord</a>
        <a href="forms.php" class="active">Formulaires</a>
        <a href="users.php">Utilisateurs</a>
        <a href="submissions.php">Soumissions</a>
        <a href="../logout.php">Déconnexion</a>
    </div>

    <div class="content">
        <div class="header">
            <h1>Gestion des formulaires</h1>
            <span>Bienvenue, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
        </div>

        <div class="card">
            <a href="../create_form.php" class="btn">+ Créer un formulaire</a>
            
            <?php if (count($forms) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Titre</th>
                        <th>Date</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($forms as $form): ?>
                    <tr>
                        <td><?php echo $form['id']; ?></td>
                        <td><?php echo htmlspecialchars($form['title']); ?></td>
                        <td><?php echo $form['created_at']; ?></td>
                        <td>
                            <?php if ($form['is_published']): ?>
                                <span class="badge-published">Publié</span>
                            <?php else: ?>
                                <span class="badge-draft">Brouillon</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="../submit_form.php?id=<?php echo $form['id']; ?>" class="btn-small">Voir</a>
                            <a href="?toggle=<?php echo $form['id']; ?>" class="btn-small btn-warning">
                                <?php echo $form['is_published'] ? 'Dépublier' : 'Publier'; ?>
                            </a>
                            <a href="?delete=<?php echo $form['id']; ?>" class="btn-small btn-danger" onclick="return confirm('Supprimer ?')">Supprimer</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p style="color: #5a7a9a; text-align: center;">Aucun formulaire.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>