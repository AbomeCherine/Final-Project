<?php
session_start();

error_log("=== users.php ===");
error_log("Session user_id: " . ($_SESSION['user_id'] ?? 'vide'));
error_log("Session username: " . ($_SESSION['username'] ?? 'vide'));
require_once '../config.php';

if (!isset($_SESSION['user_id']) || !hasRole(['admin', 'super_admin'])) {
    header('Location: ../login.php');
    exit();
}

$error = '';
$success = '';

// Ajouter un utilisateur
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];
    
    if (empty($username) || empty($email) || empty($password)) {
        $error = "Tous les champs sont obligatoires.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Email invalide.";
    } elseif (strlen($password) < 6) {
        $error = "Mot de passe (min 6 caractères).";
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->execute([$username, $email]);
        
        if ($check->rowCount() > 0) {
            $error = "Nom ou email déjà utilisé.";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO users (username, email, password, role, organization_id) VALUES (?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            
            if ($stmt->execute([$username, $email, $hashed, $role, $_SESSION['org_id']])) {
                $success = "Utilisateur ajouté.";
            } else {
                $error = "Erreur lors de l'ajout.";
            }
        }
    }
}

// Modifier le rôle
if (isset($_GET['change_role'])) {
    $userId = (int)$_GET['change_role'];
    $newRole = $_GET['role'];
    $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ? AND organization_id = ?");
    $stmt->execute([$newRole, $userId, $_SESSION['org_id']]);
    header('Location: users.php');
    exit();
}

// Supprimer un utilisateur
if (isset($_GET['delete'])) {
    $userId = (int)$_GET['delete'];
    if ($userId !== $_SESSION['user_id']) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND organization_id = ?");
        $stmt->execute([$userId, $_SESSION['org_id']]);
    }
    header('Location: users.php');
    exit();
}

$stmt = $pdo->prepare("SELECT id, username, email, role, created_at FROM users WHERE organization_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['org_id']]);
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des utilisateurs</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: #f0f2f5;
            min-height: 100vh;
        }
        .sidebar {
            width: 280px;
            background: #0a1928;
            position: fixed;
            height: 100vh;
            padding: 25px;
        }
        .sidebar h2 {
            color: white;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #1d4a6e;
        }
        .sidebar a {
            display: block;
            color: #a0c0d8;
            padding: 12px 15px;
            text-decoration: none;
            margin: 5px 0;
            border-radius: 10px;
        }
        .sidebar a:hover, .sidebar a.active {
            background: #1a4d6b;
            color: white;
        }
        .content {
            margin-left: 280px;
            padding: 30px;
        }
        .header {
            background: white;
            padding: 20px 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { color: #1a4d6b; font-size: 1.5em; }
        .card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 30px;
        }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #1a4d6b; font-weight: 500; }
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #c0d4e8;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
        }
        .btn {
            padding: 10px 20px;
            background: #1a4d6b;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        .btn-small {
            padding: 5px 12px;
            font-size: 12px;
            text-decoration: none;
            display: inline-block;
            margin: 2px;
        }
        .btn-danger { background: #c0392b; }
        .btn-warning { background: #e67e22; }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e8f0;
        }
        th {
            background: #f0f5f8;
            color: #1a4d6b;
        }
        .badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-block;
        }
        .badge-admin { background: #c0392b; color: white; }
        .badge-staff { background: #27ae60; color: white; }
        .badge-manager { background: #e67e22; color: white; }
        .error { color: #c0392b; margin-bottom: 15px; }
        .success { color: #27ae60; margin-bottom: 15px; }
        .row {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 30px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>ANAC Aviation</h2>
        <a href="dashboard.php">Tableau de bord</a>
        <a href="forms.php">Formulaires</a>
        <a href="users.php" class="active">Utilisateurs</a>
        <a href="submissions.php">Soumissions</a>
        <a href="../logout.php">Déconnexion</a>
    </div>

    <div class="content">
        <div class="header">
            <h1>Gestion des utilisateurs</h1>
            <span>Bienvenue, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="card">
                <h3>Ajouter un utilisateur</h3>
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label>Nom d'utilisateur</label>
                        <input type="text" name="username" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label>Mot de passe</label>
                        <input type="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label>Rôle</label>
                        <select name="role">
                            <option value="staff">Staff (membre)</option>
                            <option value="manager">Manager</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <button type="submit" class="btn">Ajouter</button>
                </form>
            </div>

            <div class="card">
                <h3>Liste des utilisateurs</h3>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Rôle</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <?php
                                $badgeClass = 'badge-staff';
                                if ($user['role'] === 'admin') $badgeClass = 'badge-admin';
                                if ($user['role'] === 'manager') $badgeClass = 'badge-manager';
                                ?>
                                <span class="badge <?php echo $badgeClass; ?>"><?php echo $user['role']; ?></span>
                            </td>
                            <td><?php echo $user['created_at']; ?></td>
                            <td>
                                <?php if ($user['id'] !== $_SESSION['user_id']): ?>
                                    <a href="?change_role=<?php echo $user['id']; ?>&role=staff" class="btn-small btn-warning">Staff</a>
                                    <a href="?change_role=<?php echo $user['id']; ?>&role=manager" class="btn-small btn-warning">Manager</a>
                                    <a href="?change_role=<?php echo $user['id']; ?>&role=admin" class="btn-small btn-warning">Admin</a>
                                    <a href="?delete=<?php echo $user['id']; ?>" class="btn-small btn-danger" onclick="return confirm('Supprimer ?')">Supprimer</a>
                                <?php else: ?>
                                    <span class="badge">Votre compte</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>