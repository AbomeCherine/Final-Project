<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || !hasRole(['admin', 'super_admin'])) {
    header('Location: ../login.php');
    exit();
}

$stmt = $pdo->prepare("
    SELECT s.id, s.response_data, s.submitted_at, f.title as form_title
    FROM submissions s
    JOIN forms f ON s.form_id = f.id
    WHERE f.organization_id = ?
    ORDER BY s.submitted_at DESC
");
$stmt->execute([$_SESSION['org_id']]);
$submissions = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Soumissions</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: #f0f2f5;
            min-height: 100vh;
        }
        .sidebar {
            width: 280px;
            background: #0a1928;
            position: fixed;
            height: 100vh;
            padding: 25px;
        }
        .sidebar h2 {
            color: white;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #1d4a6e;
        }
        .sidebar a {
            display: block;
            color: #a0c0d8;
            padding: 12px 15px;
            text-decoration: none;
            margin: 5px 0;
            border-radius: 10px;
        }
        .sidebar a:hover, .sidebar a.active {
            background: #1a4d6b;
            color: white;
        }
        .content {
            margin-left: 280px;
            padding: 30px;
        }
        .header {
            background: white;
            padding: 20px 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 { color: #1a4d6b; font-size: 1.5em; }
        .card {
            background: white;
            padding: 25px;
            border-radius: 15px;
        }
        .btn-small {
            padding: 5px 12px;
            font-size: 12px;
            background: #1a4d6b;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e8f0;
        }
        th {
            background: #f0f5f8;
            color: #1a4d6b;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>ANAC Aviation</h2>
        <a href="dashboard.php">Tableau de bord</a>
        <a href="forms.php">Formulaires</a>
        <a href="users.php">Utilisateurs</a>
        <a href="submissions.php" class="active">Soumissions</a>
        <a href="../logout.php">Déconnexion</a>
    </div>

    <div class="content">
        <div class="header">
            <h1>Toutes les soumissions</h1>
            <span>Bienvenue, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
        </div>

        <div class="card">
            <?php if (count($submissions) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Formulaire</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $sub): ?>
                    <tr>
                        <td><?php echo $sub['id']; ?></td>
                        <td><?php echo htmlspecialchars($sub['form_title']); ?></td>
                        <td><?php echo $sub['submitted_at']; ?></td>
                        <td>
                            <a href="submission_view.php?id=<?php echo $sub['id']; ?>" class="btn-small">Voir détails</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p style="color: #5a7a9a; text-align: center;">Aucune soumission pour le moment.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>