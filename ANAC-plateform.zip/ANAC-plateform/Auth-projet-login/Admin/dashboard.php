<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || !hasRole(['admin', 'super_admin'])) {
    header('Location: ../login.php');
    exit();
}

$stats = [];

$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM forms WHERE organization_id = ?");
$stmt->execute([$_SESSION['org_id']]);
$stats['forms'] = $stmt->fetch()['count'];

$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM submissions s JOIN forms f ON s.form_id = f.id WHERE f.organization_id = ?");
$stmt->execute([$_SESSION['org_id']]);
$stats['submissions'] = $stmt->fetch()['count'];

$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM users WHERE organization_id = ?");
$stmt->execute([$_SESSION['org_id']]);
$stats['users'] = $stmt->fetch()['count'];

$stmt = $pdo->prepare("
    SELECT s.id, s.response_data, s.submitted_at, f.title as form_title
    FROM submissions s
    JOIN forms f ON s.form_id = f.id
    WHERE f.organization_id = ?
    ORDER BY s.submitted_at DESC
    OFFSET 0 ROWS FETCH NEXT 5 ROWS ONLY
");
$stmt->execute([$_SESSION['org_id']]);
$recentSubmissions = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Aviation Portal</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: #f0f2f5;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: #0a1928;
            position: fixed;
            height: 100vh;
            padding: 25px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }

        .sidebar h2 {
            color: white;
            font-size: 1.3em;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #1d4a6e;
        }

        .sidebar a {
            display: block;
            color: #a0c0d8;
            padding: 12px 15px;
            text-decoration: none;
            margin: 5px 0;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #1a4d6b;
            color: white;
        }

        .content {
            margin-left: 280px;
            padding: 30px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px 25px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .header h1 {
            color: #1a4d6b;
            font-size: 1.5em;
        }

        .user-info span {
            color: #5a7a9a;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .stat-number {
            font-size: 2.5em;
            font-weight: 700;
            color: #1a4d6b;
        }

        .stat-label {
            color: #5a7a9a;
            margin-top: 10px;
            font-size: 0.9em;
        }

        .section-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e0e8f0;
        }

        .section-header h3 {
            color: #1a4d6b;
        }

        .btn {
            display: inline-block;
            padding: 8px 20px;
            background: #1a4d6b;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
        }

        .btn:hover {
            background: #2c6e9e;
        }

        .btn-small {
            padding: 5px 12px;
            font-size: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e8f0;
        }

        th {
            background: #f0f5f8;
            color: #1a4d6b;
            font-weight: 600;
        }

        @media (max-width: 900px) {
            .sidebar { width: 240px; }
            .content { margin-left: 240px; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 700px) {
            .sidebar { display: none; }
            .content { margin-left: 0; padding: 20px; }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>ANAC Aviation</h2>
        <a href="dashboard.php" class="active">Tableau de bord</a>
        <a href="forms.php">Formulaires</a>
        <a href="users.php">Utilisateurs</a>
        <a href="submissions.php">Soumissions</a>
        <?php if ($_SESSION['role'] === 'super_admin'): ?>
            <a href="organizations.php">Organisations</a>
        <?php endif; ?>
        <a href="../logout.php">Déconnexion</a>
    </div>

    <div class="content">
        <div class="header">
            <h1>Tableau de bord <?php echo $_SESSION['role'] === 'super_admin' ? 'Super Admin' : 'administrateur'; ?></h1>
            <div class="user-info">
                <span>Bienvenue, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['forms']; ?></div>
                <div class="stat-label">Formulaires</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['submissions']; ?></div>
                <div class="stat-label">Soumissions</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['users']; ?></div>
                <div class="stat-label">Utilisateurs</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">1</div>
                <div class="stat-label">Organisation</div>
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <h3>Actions rapides</h3>
            </div>
            <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                <a href="../create_form.php" class="btn">Créer un formulaire</a>
                <a href="users.php" class="btn">Gérer les utilisateurs</a>
                <a href="submissions.php" class="btn">Voir les soumissions</a>
            </div>
        </div>

        <div class="section-card">
            <div class="section-header">
                <h3>Dernières soumissions</h3>
                <a href="submissions.php" class="btn btn-small">Voir tout</a>
            </div>
            
            <?php if (count($recentSubmissions) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Formulaire</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentSubmissions as $sub): ?>
                    <tr>
                        <td><?php echo $sub['id']; ?></td>
                        <td><?php echo htmlspecialchars($sub['form_title']); ?></td>
                        <td><?php echo $sub['submitted_at']; ?></td>
                        <td>
                            <a href="submission_view.php?id=<?php echo $sub['id']; ?>" class="btn btn-small">Voir</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p style="color: #5a7a9a; text-align: center;">Aucune soumission pour le moment.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>