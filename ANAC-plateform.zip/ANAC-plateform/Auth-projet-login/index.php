<?php
session_start();
require_once 'config.php';

// Si déjà connecté, rediriger selon le rôle
if (isset($_SESSION['user_id'])) {
    if (hasRole(['admin', 'super_admin'])) {
        header('Location: admin/dashboard.php');
        exit();
    } else {
        header('Location: dashboard.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil - Aviation Portal</title>
   
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #0a1928 0%, #1d4a6e 50%, #2c6e9e 100%);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background: rgba(255, 255, 255, 0.98);
            padding: 50px;
            border-radius: 20px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.2);
            text-align: center;
            max-width: 650px;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(44, 110, 158, 0.3);
        }

        h1 {
            color: #1a4d6b;
            font-size: 2.8em;
            font-weight: 600;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
        }

        p {
            color: #5a7a9a;
            font-size: 1.1em;
            font-weight: 400;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 35px;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            font-weight: 500;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .btn-primary {
            background: #1a4d6b;
            color: white;
        }

        .btn-primary:hover {
            background: #2c6e9e;
        }

        .btn-secondary {
            background: #e8eef3;
            color: #1a4d6b;
        }

        .btn-secondary:hover {
            background: #d0dce8;
        }

        @media (max-width: 600px) {
            .container {
                padding: 30px 20px;
                margin: 20px;
            }
            h1 {
                font-size: 2em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Aviation Portal</h1>
        <p>Plateforme de gestion des formulaires et inspections.<br>Connectez-vous ou créez un compte pour commencer.</p>
        <div class="buttons">
            <a href="login.php" class="btn btn-primary">Se connecter</a>
            <a href="register.php" class="btn btn-secondary">S'inscrire</a>
        </div>
    </div>
</body>
</html>